#!/bin/bash
brew tap homebrew/versions
brew install llvm34 --with-libcxx --with-clang --disable-assertions --rtti
