#include "test.h"

int TestClass::someFunction(const std::string& ting)
{
    return 5;
}

bool TestClass::someOtherFunction(int hepp)
{
    return false;
}
