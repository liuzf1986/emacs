#include "stable.h"

void test()
{
    foo();
}
